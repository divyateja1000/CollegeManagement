package com.project.demo.CollegePrjct.service;

import java.util.List;

import com.project.demo.CollegePrjct.DTO.StudentDTO;
import com.project.demo.CollegePrjct.DTO.StudentSaveDTO;
import com.project.demo.CollegePrjct.DTO.StudentUpdateDTO;


public interface StudentInterface {
	String addStudent(StudentSaveDTO studentSaveDTO);
	 
    List<StudentDTO> getAllStudent();
 
    String updateStudent(StudentUpdateDTO studentUpdateDTO);
 
    boolean deleteStudent(int id);

}
