package com.project.demo.CollegePrjct.service;

import java.util.List;

import com.project.demo.CollegePrjct.DTO.FacultyDTO;
import com.project.demo.CollegePrjct.DTO.FacultySaveDTO;
import com.project.demo.CollegePrjct.DTO.FacultyUpdateDTO;

public interface FacultyInterface {
	String addFaculty(FacultySaveDTO facultySaveDTO);
	List<FacultyDTO>getAllFaculty();
	String updateFaculty(FacultyUpdateDTO facultyUpdateDTO);
	boolean deleteFaculty(int id);


}
