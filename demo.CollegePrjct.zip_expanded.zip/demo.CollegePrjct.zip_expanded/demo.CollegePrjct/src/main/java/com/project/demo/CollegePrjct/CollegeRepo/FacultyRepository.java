package com.project.demo.CollegePrjct.CollegeRepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.project.demo.CollegePrjct.entity.Faculty;
@EnableJpaRepositories
@Repository

public interface FacultyRepository extends JpaRepository<Faculty,Integer>{

}
