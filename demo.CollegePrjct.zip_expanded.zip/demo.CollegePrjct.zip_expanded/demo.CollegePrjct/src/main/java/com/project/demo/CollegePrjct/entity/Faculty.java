package com.project.demo.CollegePrjct.entity;
import javax.persistence.*;

import lombok.Data;

@Entity
@Table(name="faculty")
@Data

public class Faculty {
	@Id
	@Column(name="Faculty_id",length=50)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int facultyid;
	@Column(name="Faculty_name",length=50)
	private String facultyname;
	@Column(name="Experience",length=100)
	private String experience;
	@Column(name="Faculty_mobile",length=12)
	private int mobile;
	@Column(name="Faculty_email",length=50)
	private String email;
	@Column(name="Department",length=50)
	private String department;
	public Faculty(int facultyid, String facultyname, String experience, int mobile, String email,String department) {
		this.facultyid = facultyid;
		this.facultyname = facultyname;
		this.experience = experience;
		this.mobile = mobile;
		this.email=email;
		this.department=department;
		}
	public Faculty() {
	}

	public Faculty(String facultyname, String experience, int mobile, String email,String department) {
		this.facultyname = facultyname;
		this.experience = experience;
		this.mobile = mobile;
		this.email=email;
		this.department=department;
	}
	public int getFacultyid() {
		return facultyid;
	}
	public void setFacultyid(int facultyid) {
		this.facultyid = facultyid;
	}
	public String getFacultyname() {
		return facultyname;
	}
	public void setFacultyname(String facultyname) {
		this.facultyname = facultyname;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Faculty [facultyid=" + facultyid + ", facultyname=" + facultyname + ", experience=" + experience
				+ ", mobile=" + mobile + ", email=" + email + ", department=" + department + "]";
	}
	
	
}
