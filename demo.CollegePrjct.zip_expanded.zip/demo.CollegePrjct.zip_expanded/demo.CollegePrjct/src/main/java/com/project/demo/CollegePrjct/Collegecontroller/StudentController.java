package com.project.demo.CollegePrjct.Collegecontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.demo.CollegePrjct.DTO.StudentDTO;
import com.project.demo.CollegePrjct.DTO.StudentSaveDTO;
import com.project.demo.CollegePrjct.DTO.StudentUpdateDTO;
import com.project.demo.CollegePrjct.service.StudentInterface;


@RestController //It is used for sending the data.
@CrossOrigin
@RequestMapping("api/v1/student")
public class StudentController {
	@Autowired
    private StudentInterface studentService;
 
    @PostMapping(path = "/save")
 
    public String saveStudent(@RequestBody StudentSaveDTO studentSaveDTO)
    {
        String id = studentService.addStudent(studentSaveDTO);
        return id;
    }
 
    @GetMapping(path = "/getAllStudent")
    public List<StudentDTO> getAllStudent()
    {
       List<StudentDTO>allStudent = studentService.getAllStudent();
       return allStudent;
    }
 
    @PutMapping(path = "/update")
 
    public String updateStudent(@RequestBody StudentUpdateDTO studentUpdateDTO)
    {
        String id = studentService.updateStudent(studentUpdateDTO);
        return id;
    }
 
    @DeleteMapping(path = "/deletestudent/{id}")
    public String deleteCustomer(@PathVariable(value = "id") int id)
    {
        boolean deletestudent = studentService.deleteStudent(id);
        return "deleted";
    }
 

}
