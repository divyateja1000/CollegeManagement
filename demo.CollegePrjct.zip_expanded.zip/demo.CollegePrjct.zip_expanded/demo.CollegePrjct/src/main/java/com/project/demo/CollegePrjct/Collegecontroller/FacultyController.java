package com.project.demo.CollegePrjct.Collegecontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.demo.CollegePrjct.DTO.FacultyDTO;
import com.project.demo.CollegePrjct.DTO.FacultySaveDTO;
import com.project.demo.CollegePrjct.DTO.FacultyUpdateDTO;
import com.project.demo.CollegePrjct.service.FacultyInterface;

@RestController //It is used for sending the data.
@CrossOrigin
@RequestMapping("api/v1/faculty")
public class FacultyController {
@Autowired
private FacultyInterface facultyService;
@PostMapping(path = "/save")

public String saveFaculty(@RequestBody FacultySaveDTO facultySaveDTO)
{
    String id = facultyService.addFaculty(facultySaveDTO);
    return id;
}

@GetMapping(path = "/getAllFaculty")
public List<FacultyDTO> getAllFaculty()
{
   List<FacultyDTO>allFaculty = facultyService.getAllFaculty();
   return allFaculty;
}

@PutMapping(path = "/update")

public String updateFaculty(@RequestBody FacultyUpdateDTO facultyUpdateDTO)
{
    String id = facultyService.updateFaculty(facultyUpdateDTO);
    return id;
}

@DeleteMapping(path = "/deletefaculty/{id}")
public String deleteFaculty(@PathVariable(value = "id") int id)
{
    boolean deletefaculty = facultyService.deleteFaculty(id);
    return "deleted";
}
}
