package com.project.demo.CollegePrjct.CollegeRepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.demo.CollegePrjct.entity.Student;

public interface StudentRepositary extends JpaRepository<Student,Integer>{

}
