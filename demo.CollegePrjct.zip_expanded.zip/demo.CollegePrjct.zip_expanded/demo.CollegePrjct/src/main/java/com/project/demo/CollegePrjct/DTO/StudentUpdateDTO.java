package com.project.demo.CollegePrjct.DTO;

public class StudentUpdateDTO {
	private int studentid;
	private String name;
	private String course;
	private String gender;
	private int mobile;	
	private String email;
	private int age;
	private String address;
	public StudentUpdateDTO(int studentid, String name, String course, String gender, int mobile, String email,
			int age, String address) {
		this.studentid = studentid;
		this.name = name;
		this.course = course;
		this.gender = gender;
		this.mobile = mobile;
		this.email = email;
		this.age = age;
		this.address = address;
	}
	public StudentUpdateDTO() {
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "StudentUpdateDTO [studentid=" + studentid + ", name=" + name + ", course=" + course + ", gender="
				+ gender + ", mobile=" + mobile + ", email=" + email + ", age=" + age + ", address=" + address + "]";
	}
	
}
