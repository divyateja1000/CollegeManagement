package com.project.demo.CollegePrjct.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.demo.CollegePrjct.CollegeRepo.StudentRepositary;
import com.project.demo.CollegePrjct.DTO.StudentDTO;
import com.project.demo.CollegePrjct.DTO.StudentSaveDTO;
import com.project.demo.CollegePrjct.DTO.StudentUpdateDTO;
import com.project.demo.CollegePrjct.entity.Student;



@Service
public class StudentServiceIMPL implements StudentInterface{
	@Autowired
	private StudentRepositary studentRepo;
	 
    @Override
    public String addStudent(StudentSaveDTO studentSaveDTO)
    {
    	Student student = new Student(
 
    			studentSaveDTO.getName(),
    			studentSaveDTO.getCourse(),
    			studentSaveDTO.getGender(),
    			studentSaveDTO.getMobile(),
    			studentSaveDTO.getEmail(),
    			studentSaveDTO.getAge(),
    			studentSaveDTO.getAddress()
        );
    	studentRepo.save(student);
        return student.getName();
    }
 
    @Override
    public List<StudentDTO> getAllStudent() {
       List<Student> getStudent = studentRepo.findAll();
       List<StudentDTO> studentDTOList = new ArrayList<>();
       for(Student a:getStudent)
       {
    	   StudentDTO studentDTO = new StudentDTO(
 
                   a.getStudentid(),
                   a.getName(),
                   a.getCourse(),
                   a.getGender(),
                   a.getMobile(),
                   a.getEmail(),
                   a.getAge(),
                   a.getAddress()
                              );
           studentDTOList.add(studentDTO);
       }
 
       return  studentDTOList;
    }
 
    @Override
    public String updateStudent(StudentUpdateDTO studentUpdateDTO)
    {
        if (studentRepo.existsById(studentUpdateDTO.getStudentid())) {
        	Student student = studentRepo.getById(studentUpdateDTO.getStudentid());
 
 
        	student.setName(studentUpdateDTO.getName());
        	student.setCourse(studentUpdateDTO.getCourse());
        	student.setGender(studentUpdateDTO.getGender());
        	student.setMobile(studentUpdateDTO.getMobile());
        	student.setEmail(studentUpdateDTO.getEmail());
        	student.setAge(studentUpdateDTO.getAge());
        	student.setAddress(studentUpdateDTO.getAddress());
            studentRepo.save(student);
        }
            else
            {
                System.out.println("Student ID do not Exist");
            }
 
                return null;
        }
 
    @Override
    public boolean deleteStudent(int id) {
 
        if(studentRepo.existsById(id))
        {
            studentRepo.deleteById(id);
        }
        else
        {
            System.out.println("students id not found");
        }
        return true;
    }

}
