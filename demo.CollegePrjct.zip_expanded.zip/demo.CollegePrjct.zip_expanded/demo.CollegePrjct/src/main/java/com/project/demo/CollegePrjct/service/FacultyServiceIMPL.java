package com.project.demo.CollegePrjct.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.demo.CollegePrjct.CollegeRepo.FacultyRepository;
import com.project.demo.CollegePrjct.DTO.FacultyDTO;
import com.project.demo.CollegePrjct.DTO.FacultySaveDTO;
import com.project.demo.CollegePrjct.DTO.FacultyUpdateDTO;
import com.project.demo.CollegePrjct.entity.Faculty;

@Service
public class FacultyServiceIMPL implements FacultyInterface{
 @Autowired
 private FacultyRepository facultyRepo;
 @Override
 public String addFaculty(FacultySaveDTO facultySaveDTO)
 {
	 Faculty faculty = new Faculty(

			 facultySaveDTO.getFacultyname(),
			 facultySaveDTO.getExperience(),
             facultySaveDTO.getMobile(),
             facultySaveDTO.getEmail(),
             facultySaveDTO.getDepartment()
     );
	 facultyRepo.save(faculty);
     return faculty.getFacultyname();
 }

 @Override
 public List<FacultyDTO> getAllFaculty() {
    List<Faculty> getFaculty = facultyRepo.findAll();
    List<FacultyDTO> facultyDTOList = new ArrayList<>();
    for(Faculty a:getFaculty)
    {
    	FacultyDTO facultyDTO = new FacultyDTO(

    			   a.getFacultyid(),
                a.getFacultyname(),
                a.getExperience(),
                a.getMobile(),
                a.getEmail(),
                a.getDepartment()
        );
    	facultyDTOList.add(facultyDTO);
    }

    return  facultyDTOList;
 }

 @Override
 public String updateFaculty(FacultyUpdateDTO facultyUpdateDTO)
 {
     if (facultyRepo.existsById(facultyUpdateDTO.getFacultyid())) {
    	 Faculty faculty = facultyRepo.getById(facultyUpdateDTO.getFacultyid());


    	 faculty.setFacultyname(facultyUpdateDTO.getFacultyname());
    	 faculty.setExperience(facultyUpdateDTO.getExperience());
    	 faculty.setMobile(facultyUpdateDTO.getMobile());
    	 faculty.setEmail(facultyUpdateDTO.getEmail());
    	 faculty.setDepartment(facultyUpdateDTO.getDepartment());

    	 facultyRepo.save(faculty);
     }
         else
         {
             System.out.println("faculty ID do not Exist");
         }

             return null;
     }

 @Override
 public boolean deleteFaculty(int id) {

     if(facultyRepo.existsById(id))
     {
    	 facultyRepo.deleteById(id);
     }
     else
     {
         System.out.println("Faculty id not found");
     }
     return true;
 }


}
